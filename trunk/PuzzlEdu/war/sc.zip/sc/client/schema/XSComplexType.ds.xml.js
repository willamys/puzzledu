isc.DataSource.create({Constructor:"XSComplexType", inheritsFrom:"DataSource", ID:"XSComplexType", addGlobalId:false})
