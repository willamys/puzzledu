isc.DataSource.create({Constructor:"WSDLMessage", inheritsFrom:"DataSource", ID:"WSDLMessage", addGlobalId:false})
