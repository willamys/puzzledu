isc.DataSource.create({
    Constructor:"SimpleType",
    inheritsFrom:"DataSourceField",
    ID:"SimpleType",
    fields:{
        inheritsFrom:{type:"string", name:"inheritsFrom"},
        editorType:{type:"string", name:"editorType"}
    },
    addGlobalId:false
})
