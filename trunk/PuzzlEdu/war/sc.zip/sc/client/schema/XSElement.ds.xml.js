isc.DataSource.create({Constructor:"XSElement", inheritsFrom:"DataSource", ID:"XSElement", addGlobalId:false})
